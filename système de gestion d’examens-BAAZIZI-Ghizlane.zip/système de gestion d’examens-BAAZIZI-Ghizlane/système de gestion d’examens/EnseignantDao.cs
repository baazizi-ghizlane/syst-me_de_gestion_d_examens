﻿using System;
using System.Collections.Generic;
using System.IO;

namespace système_de_gestion_d_examens
{
    internal class EnseignantDao
    {
        private static readonly string filePath = "C:\\Users\\Lenovo\\OneDrive - ISGA\\&isi cours\\S2\\c#\\système_de_gestion_d_examens\\Data\\enseignants.csv";

        public static List<Enseignant> GetAll()
        {
            var enseignants = new List<Enseignant>();
            if (!File.Exists(filePath)) return enseignants;

            foreach (var line in File.ReadAllLines(filePath))
            {
                var parts = line.Split(',');
                if (parts.Length >= 5)
                {
                    enseignants.Add(new Enseignant
                    {
                        Id = int.Parse(parts[0]),
                        Nom = parts[1],
                        Prenom1 = parts[2],
                        Email1 = parts[3],
                        Specialite1 = parts[4]
                    });
                }
            }
            return enseignants;
        }

        public static void Save(Enseignant e)
        {
            using (StreamWriter sw = File.AppendText(filePath))
            {
                sw.WriteLine($"{e.Id},{e.Nom},{e.Prenom1},{e.Email1},{e.Specialite1}");
            }
        }
    }
}