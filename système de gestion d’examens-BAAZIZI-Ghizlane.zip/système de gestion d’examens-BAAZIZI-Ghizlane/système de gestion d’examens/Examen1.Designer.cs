﻿

namespace système_de_gestion_d_examen

{
    partial class Examen1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.TextBox txtDuree;
        private System.Windows.Forms.TextBox txtMatiereId;
        private System.Windows.Forms.TextBox txtEnseignantId;
        private System.Windows.Forms.TextBox txtSalle;
        private System.Windows.Forms.CheckBox cbEstTermine;
        private System.Windows.Forms.DateTimePicker dtpDateHeure;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Label lblNom;
        private System.Windows.Forms.Label lblDateHeure;
        private System.Windows.Forms.Label lblDuree;
        private System.Windows.Forms.Label lblMatiereId;
        private System.Windows.Forms.Label lblEnseignantId;
        private System.Windows.Forms.Label lblSalle;
        private System.Windows.Forms.Label lblEstTermine;
        private System.Windows.Forms.Button btnEnregistrer;
        private System.Windows.Forms.Button btnAnnuler;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtId = new System.Windows.Forms.TextBox();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.txtDuree = new System.Windows.Forms.TextBox();
            this.txtMatiereId = new System.Windows.Forms.TextBox();
            this.txtEnseignantId = new System.Windows.Forms.TextBox();
            this.txtSalle = new System.Windows.Forms.TextBox();
            this.cbEstTermine = new System.Windows.Forms.CheckBox();
            this.dtpDateHeure = new System.Windows.Forms.DateTimePicker();
            this.lblId = new System.Windows.Forms.Label();
            this.lblNom = new System.Windows.Forms.Label();
            this.lblDateHeure = new System.Windows.Forms.Label();
            this.lblDuree = new System.Windows.Forms.Label();
            this.lblMatiereId = new System.Windows.Forms.Label();
            this.lblEnseignantId = new System.Windows.Forms.Label();
            this.lblSalle = new System.Windows.Forms.Label();
            this.lblEstTermine = new System.Windows.Forms.Label();
            this.btnEnregistrer = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.SuspendLayout();

            this.txtId.Location = new System.Drawing.Point(139, 38);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(100, 20);
            this.txtId.TabIndex = 0;

            this.txtNom.Location = new System.Drawing.Point(139, 68);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(100, 20);
            this.txtNom.TabIndex = 1;


            this.txtDuree.Location = new System.Drawing.Point(139, 98);
            this.txtDuree.Name = "txtDuree";
            this.txtDuree.Size = new System.Drawing.Size(100, 20);
            this.txtDuree.TabIndex = 2;


            this.txtMatiereId.Location = new System.Drawing.Point(139, 128);
            this.txtMatiereId.Name = "txtMatiereId";
            this.txtMatiereId.Size = new System.Drawing.Size(100, 20);
            this.txtMatiereId.TabIndex = 3;


            this.txtEnseignantId.Location = new System.Drawing.Point(139, 158);
            this.txtEnseignantId.Name = "txtEnseignantId";
            this.txtEnseignantId.Size = new System.Drawing.Size(100, 20);
            this.txtEnseignantId.TabIndex = 4;

            this.txtSalle.Location = new System.Drawing.Point(139, 188);
            this.txtSalle.Name = "txtSalle";
            this.txtSalle.Size = new System.Drawing.Size(100, 20);
            this.txtSalle.TabIndex = 5;

            this.cbEstTermine.AutoSize = true;
            this.cbEstTermine.Location = new System.Drawing.Point(139, 218);
            this.cbEstTermine.Name = "cbEstTermine";
            this.cbEstTermine.Size = new System.Drawing.Size(87, 17);
            this.cbEstTermine.TabIndex = 6;
            this.cbEstTermine.Text = "Est Terminé";
            this.cbEstTermine.UseVisualStyleBackColor = true;


            this.dtpDateHeure.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateHeure.Location = new System.Drawing.Point(139, 248);
            this.dtpDateHeure.Name = "dtpDateHeure";
            this.dtpDateHeure.Size = new System.Drawing.Size(100, 20);
            this.dtpDateHeure.TabIndex = 7;

            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(22, 41);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(20, 13);
            this.lblId.TabIndex = 8;
            this.lblId.Text = "ID";

            this.lblNom.AutoSize = true;
            this.lblNom.Location = new System.Drawing.Point(22, 71);
            this.lblNom.Name = "lblNom";
            this.lblNom.Size = new System.Drawing.Size(29, 13);
            this.lblNom.TabIndex = 9;
            this.lblNom.Text = "Nom";


            this.lblDateHeure.AutoSize = true;
            this.lblDateHeure.Location = new System.Drawing.Point(22, 251);
            this.lblDateHeure.Name = "lblDateHeure";
            this.lblDateHeure.Size = new System.Drawing.Size(54, 13);
            this.lblDateHeure.TabIndex = 10;
            this.lblDateHeure.Text = "Date Heure";


            this.lblDuree.AutoSize = true;
            this.lblDuree.Location = new System.Drawing.Point(22, 101);
            this.lblDuree.Name = "lblDuree";
            this.lblDuree.Size = new System.Drawing.Size(35, 13);
            this.lblDuree.TabIndex = 11;
            this.lblDuree.Text = "Durée";


            this.lblMatiereId.AutoSize = true;
            this.lblMatiereId.Location = new System.Drawing.Point(22, 131);
            this.lblMatiereId.Name = "lblMatiereId";
            this.lblMatiereId.Size = new System.Drawing.Size(52, 13);
            this.lblMatiereId.TabIndex = 12;
            this.lblMatiereId.Text = "Matière ID";

            this.lblEnseignantId.AutoSize = true;
            this.lblEnseignantId.Location = new System.Drawing.Point(22, 161);
            this.lblEnseignantId.Name = "lblEnseignantId";
            this.lblEnseignantId.Size = new System.Drawing.Size(71, 13);
            this.lblEnseignantId.TabIndex = 13;
            this.lblEnseignantId.Text = "Enseignant ID";
 
            this.lblSalle.AutoSize = true;
            this.lblSalle.Location = new System.Drawing.Point(22, 191);
            this.lblSalle.Name = "lblSalle";
            this.lblSalle.Size = new System.Drawing.Size(30, 13);
            this.lblSalle.TabIndex = 14;
            this.lblSalle.Text = "Salle";
           
            this.lblEstTermine.AutoSize = true;
            this.lblEstTermine.Location = new System.Drawing.Point(22, 221);
            this.lblEstTermine.Name = "lblEstTermine";
            this.lblEstTermine.Size = new System.Drawing.Size(55, 13);
            this.lblEstTermine.TabIndex = 15;
            this.lblEstTermine.Text = "Est Terminé";
           
            this.btnEnregistrer.Location = new System.Drawing.Point(139, 278);
            this.btnEnregistrer.Name = "btnEnregistrer";
            this.btnEnregistrer.Size = new System.Drawing.Size(75, 23);
            this.btnEnregistrer.TabIndex = 16;
            this.btnEnregistrer.Text = "Enregistrer";
            this.btnEnregistrer.UseVisualStyleBackColor = true;
            this.btnEnregistrer.Click += new System.EventHandler(this.btnEnregistrer_Click);
           
            this.btnAnnuler.Location = new System.Drawing.Point(220, 278);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(75, 23);
            this.btnAnnuler.TabIndex = 17;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
           
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 319);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnEnregistrer);
            this.Controls.Add(this.lblEstTermine);
            this.Controls.Add(this.lblSalle);
            this.Controls.Add(this.lblEnseignantId);
            this.Controls.Add(this.lblMatiereId);
            this.Controls.Add(this.lblDuree);
            this.Controls.Add(this.lblDateHeure);
            this.Controls.Add(this.lblNom);
            this.Controls.Add(this.lblId);
            this.Controls.Add(this.cbEstTermine);
            this.Controls.Add(this.dtpDateHeure);
            this.Controls.Add(this.txtSalle);
            this.Controls.Add(this.txtEnseignantId);
            this.Controls.Add(this.txtMatiereId);
            this.Controls.Add(this.txtDuree);
            this.Controls.Add(this.txtNom);
            this.Controls.Add(this.txtId);
            this.Name = "Examen1";
            this.Text = "Examen1";
            this.Load += new System.EventHandler(this.Examen1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}