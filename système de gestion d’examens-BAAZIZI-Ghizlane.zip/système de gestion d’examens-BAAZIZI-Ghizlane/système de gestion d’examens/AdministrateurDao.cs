﻿using System;
using System.Collections.Generic;
using System.IO;

namespace système_de_gestion_d_examens
{
    internal class AdministrateurDao
    {
        private static readonly string filePath = "C:\\Users\\Lenovo\\OneDrive - ISGA\\&isi cours\\S2\\c#\\système_de_gestion_d_examens\\Data\\administrateurs.csv";

        public static List<Administrateur> GetAll()
        {
            var admins = new List<Administrateur>();
            if (!File.Exists(filePath)) return admins;

            foreach (var line in File.ReadAllLines(filePath))
            {
                var parts = line.Split(',');
                if (parts.Length >= 5)
                {
                    admins.Add(new Administrateur
                    {
                        Id = int.Parse(parts[0]),
                        Nom = parts[1],
                        Prenom1 = parts[2],
                        Email1 = parts[3],
                        Role1 = parts[4],

                    });
                }
            }
            return admins;
        }

        public static void Save(Administrateur a)
        {
            using (StreamWriter sw = File.AppendText(filePath))

            {
                sw.WriteLine($"{a.Id},{a.Nom},{a.Prenom1},{a.Email1},{a.Role1}");
            }
        }
    }
}