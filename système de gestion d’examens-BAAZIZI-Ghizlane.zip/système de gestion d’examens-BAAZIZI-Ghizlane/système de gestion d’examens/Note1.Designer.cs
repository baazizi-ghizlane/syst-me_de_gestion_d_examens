﻿namespace  système_de_gestion_d_examen

{
    partial class Note1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.TextBox txtEtudiantId;
        private System.Windows.Forms.TextBox txtExamenId;
        private System.Windows.Forms.TextBox txtValeur;
        private System.Windows.Forms.TextBox txtCommentaire;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Label lblEtudiantId;
        private System.Windows.Forms.Label lblExamenId;
        private System.Windows.Forms.Label lblValeur;
        private System.Windows.Forms.Label lblCommentaire;
        private System.Windows.Forms.Button btnEnregistrer;
        private System.Windows.Forms.Button btnAnnuler;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtId = new System.Windows.Forms.TextBox();
            this.txtEtudiantId = new System.Windows.Forms.TextBox();
            this.txtExamenId = new System.Windows.Forms.TextBox();
            this.txtValeur = new System.Windows.Forms.TextBox();
            this.txtCommentaire = new System.Windows.Forms.TextBox();
            this.lblId = new System.Windows.Forms.Label();
            this.lblEtudiantId = new System.Windows.Forms.Label();
            this.lblExamenId = new System.Windows.Forms.Label();
            this.lblValeur = new System.Windows.Forms.Label();
            this.lblCommentaire = new System.Windows.Forms.Label();
            this.btnEnregistrer = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.SuspendLayout();


            this.txtId.Location = new System.Drawing.Point(139, 38);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(100, 20);
            this.txtId.TabIndex = 0;

            this.txtEtudiantId.Location = new System.Drawing.Point(139, 68);
            this.txtEtudiantId.Name = "txtEtudiantId";
            this.txtEtudiantId.Size = new System.Drawing.Size(100, 20);
            this.txtEtudiantId.TabIndex = 1;

            this.txtExamenId.Location = new System.Drawing.Point(139, 98);
            this.txtExamenId.Name = "txtExamenId";
            this.txtExamenId.Size = new System.Drawing.Size(100, 20);
            this.txtExamenId.TabIndex = 2;

            this.txtValeur.Location = new System.Drawing.Point(139, 128);
            this.txtValeur.Name = "txtValeur";
            this.txtValeur.Size = new System.Drawing.Size(100, 20);
            this.txtValeur.TabIndex = 3;

            this.txtCommentaire.Location = new System.Drawing.Point(139, 158);
            this.txtCommentaire.Name = "txtCommentaire";
            this.txtCommentaire.Size = new System.Drawing.Size(100, 20);
            this.txtCommentaire.TabIndex = 4;

            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(22, 41);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(20, 13);
            this.lblId.TabIndex = 5;
            this.lblId.Text = "ID";

            this.lblEtudiantId.AutoSize = true;
            this.lblEtudiantId.Location = new System.Drawing.Point(22, 71);
            this.lblEtudiantId.Name = "lblEtudiantId";
            this.lblEtudiantId.Size = new System.Drawing.Size(52, 13);
            this.lblEtudiantId.TabIndex = 6;
            this.lblEtudiantId.Text = "Etudiant ID";

            this.lblExamenId.AutoSize = true;
            this.lblExamenId.Location = new System.Drawing.Point(22, 101);
            this.lblExamenId.Name = "lblExamenId";
            this.lblExamenId.Size = new System.Drawing.Size(52, 13);
            this.lblExamenId.TabIndex = 7;
            this.lblExamenId.Text = "Examen ID";

            this.lblValeur.AutoSize = true;
            this.lblValeur.Location = new System.Drawing.Point(22, 131);
            this.lblValeur.Name = "lblValeur";
            this.lblValeur.Size = new System.Drawing.Size(35, 13);
            this.lblValeur.TabIndex = 8;
            this.lblValeur.Text = "Valeur";
 
            this.lblCommentaire.AutoSize = true;
            this.lblCommentaire.Location = new System.Drawing.Point(22, 161);
            this.lblCommentaire.Name = "lblCommentaire";
            this.lblCommentaire.Size = new System.Drawing.Size(61, 13);
            this.lblCommentaire.TabIndex = 9;
            this.lblCommentaire.Text = "Commentaire";


            this.btnEnregistrer.Location = new System.Drawing.Point(139, 189);
            this.btnEnregistrer.Name = "btnEnregistrer";
            this.btnEnregistrer.Size = new System.Drawing.Size(75, 23);
            this.btnEnregistrer.TabIndex = 10;
            this.btnEnregistrer.Text = "Enregistrer";
            this.btnEnregistrer.UseVisualStyleBackColor = true;
            this.btnEnregistrer.Click += new System.EventHandler(this.btnEnregistrer_Click);


            this.btnAnnuler.Location = new System.Drawing.Point(220, 189);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(75, 23);
            this.btnAnnuler.TabIndex = 11;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);


            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnEnregistrer);
            this.Controls.Add(this.lblCommentaire);
            this.Controls.Add(this.lblValeur);
            this.Controls.Add(this.lblExamenId);
            this.Controls.Add(this.lblEtudiantId);
            this.Controls.Add(this.lblId);
            this.Controls.Add(this.txtCommentaire);
            this.Controls.Add(this.txtValeur);
            this.Controls.Add(this.txtExamenId);
            this.Controls.Add(this.txtEtudiantId);
            this.Controls.Add(this.txtId);
            this.Name = "Note1";
            this.Text = "Note1";
            this.Load += new System.EventHandler(this.Note1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}