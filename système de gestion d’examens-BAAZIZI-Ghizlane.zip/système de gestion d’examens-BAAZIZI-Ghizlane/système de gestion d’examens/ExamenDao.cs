﻿using System;
using System.Collections.Generic;
using System.IO;

namespace système_de_gestion_d_examens
{
    internal class ExamenDao
    {
        private static readonly string filePath = "C:\\Users\\Lenovo\\OneDrive - ISGA\\&isi cours\\S2\\c#\\système_de_gestion_d_examens\\Data\\examens.csv";

        public static List<Examen> GetAll()
        {
            var examens = new List<Examen>();
            if (!File.Exists(filePath)) return examens;

            foreach (var line in File.ReadAllLines(filePath))
            {
                var parts = line.Split(',');
                if (parts.Length >= 8)
                {
                    examens.Add(new Examen
                    {
                        Id = int.Parse(parts[0]),
                        Nom = parts[1],
                        DateHeure1 = DateTime.Parse(parts[2]),
                        Duree = int.Parse(parts[3]),
                        MatiereId = int.Parse(parts[4]),
                        EnseignantId = int.Parse(parts[5]),
                        Salle = parts[6],
                        EstTermine = bool.Parse(parts[7])
                    });
                }
            }
            return examens;
        }

        public static void Save(Examen e)
        {
            using (StreamWriter sw = File.AppendText(filePath))
            {
                sw.WriteLine($"{e.Id},{e.Nom},{e.DateHeure1},{e.Duree},{e.MatiereId},{e.EnseignantId},{e.Salle},{e.EstTermine}");
            }
        }
    }
}