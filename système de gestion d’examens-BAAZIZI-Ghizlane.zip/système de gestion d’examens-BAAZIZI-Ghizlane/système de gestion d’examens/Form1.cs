namespace syst�me_de_gestion_d_examen
{
    public partial class Form1 : Form
    {
        EtudiantDao dao = new EtudiantDao();
        ModuleDao moduleDao = new ModuleDao();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = Int32.Parse(textBox1.Text);
            string nom = textBox2.Text;
            string prenom = textBox3.Text;
            dao.addEtudiant(id, nom, prenom);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int id = Int32.Parse(textBox1.Text);
            Etudiant ee = dao.findEtudiantById(id);
            textBox2.Text = ee.Nom;
            textBox3.Text = ee.Prenom;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int id = Int32.Parse(textBox4.Text);
            string lib = textBox5.Text;
            double coiff = Double.Parse(textBox6.Text);
            moduleDao.addModule(id, lib, coiff);
        }

        private void ajouterToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Matiere1 m = new Matiere1();
            m.Visible = true;
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Examen1 exiham = new Examen1();
            exiham.Visible = true;

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
