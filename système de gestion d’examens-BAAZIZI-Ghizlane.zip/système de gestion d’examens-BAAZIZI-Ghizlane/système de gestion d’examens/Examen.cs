﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace système_de_gestion_d_examens
{
    internal class Examen
    {
        int id;
        string nom;
        DateTime DateHeure;
        int duree;
        int matiereId;
        int enseignantId;
        string salle;
        bool estTermine;

        public int Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }
        public DateTime DateHeure1 { get => DateHeure; set => DateHeure = value; }
        public int Duree { get => duree; set => duree = value; }
        public int MatiereId { get => matiereId; set => matiereId = value; }
        public int EnseignantId { get => enseignantId; set => enseignantId = value; }
        public string Salle { get => salle; set => salle = value; }
        public bool EstTermine { get => estTermine; set => estTermine = value; }
    }
}
