

    using System;
    using System.Windows.Forms;
    using syst�me_de_gestion_d_examens;

namespace syst�me_de_gestion_d_examen
{
        public partial class Etudiant1 : Form
        {
            private EtudiantDao etudiantDao = new EtudiantDao();

            public Etudiant1()
            {
                InitializeComponent();
            }

            private void Etudiant1_Load(object sender, EventArgs e)
            {

            }

            private void btnEnregistrer_Click(object sender, EventArgs e)
            {
                try
                {
                    int id = int.Parse(txtId.Text);
                    string nom = txtNom.Text;
                    string prenom = txtPrenom.Text;
                    string email = txtEmail.Text;
                    string numeroEtudiant = txtNumeroEtudiant.Text;
                    DateTime dateInscription = dtpDateInscription.Value;

                    Etudiant etudiant = new Etudiant
                    {
                        Id = id,
                        Nom = nom,
                        Prenom = prenom,
                        Email = email,
                        NumeroEtudiant = numeroEtudiant,
                        DateInscription = dateInscription
                    };

                    EtudiantDao.Save(etudiant);

                    MessageBox.Show("�tudiant enregistr� avec succ�s!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de l'enregistrement de l'�tudiant: " + ex.Message);
                }
            }

            private void btnAnnuler_Click(object sender, EventArgs e)
            {
                this.Close();
            }
        }
    }