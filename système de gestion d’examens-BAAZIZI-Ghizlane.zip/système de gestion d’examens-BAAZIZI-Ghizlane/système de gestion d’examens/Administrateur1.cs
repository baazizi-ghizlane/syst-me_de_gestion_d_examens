﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using système_de_gestion_d_examens;

namespace système_de_gestion_d_examen

    {
        public partial class Administrateur1 : Form
        {
            private AdministrateurDao administrateurDao = new AdministrateurDao();

            public Administrateur1()
            {

            }

            private void Administrateur1_Load(object sender, EventArgs e)
            {

            }

            private void btnEnregistrer_Click(object sender, EventArgs e)
            {
                try
                {
                    int id = int.Parse(txtId.Text);
                    string nom = txtNom.Text;
                    string prenom = txtPrenom.Text;
                    string email = txtEmail.Text;
                    string role = txtRole.Text;

                    Administrateur administrateur = new Administrateur { Id = id, Nom = nom, Prenom = prenom, Email = email, Role = role };
                    AdministrateurDao.Save(administrateur);

                    MessageBox.Show("Administrateur enregistré avec succès!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de l'enregistrement de l'administrateur: " + ex.Message);
                }
            }

            private void btnAnnuler_Click(object sender, EventArgs e)
            {
                this.Close();
            }
        }
    }
