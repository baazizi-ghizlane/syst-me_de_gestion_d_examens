﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace système_de_gestion_d_examens
{
    internal class EtudiantDao
    {
        private static readonly string filePath = "C:\\Users\\Lenovo\\OneDrive - ISGA\\&isi cours\\S2\\c#\\système_de_gestion_d_examens\\Data\\etudiants.csv";

        public static List<Etudiant> GetAll()
        {
            var etudiants = new List<Etudiant>();
            if (!File.Exists(filePath)) return etudiants;

            foreach (var line in File.ReadAllLines(filePath))
            {
                var parts = line.Split(',');
                if (parts.Length >= 6)
                {
                    etudiants.Add(new Etudiant
                    {
                        Id = int.Parse(parts[0]),
                        Nom = parts[1],
                        Prenom1 = parts[2],
                        Email1 = parts[3],
                        NumeroEtudiant1 = parts[4],
                        DateInscription1 = DateTime.Parse(parts[5])
                    });
                }
            }
            return etudiants;
        }

        public static void Save(Etudiant e)
        {
            using (StreamWriter sw = File.AppendText(filePath))
            {
                sw.WriteLine($"{e.Id},{e.Nom},{e.Prenom1},{e.Email1},{e.NumeroEtudiant1},{e.DateInscription1}");
            }
        }
    }
}