﻿namespace système_de_gestion_d_examen

{
    partial class Etudiant1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.TextBox txtPrenom;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtNumeroEtudiant;
        private System.Windows.Forms.DateTimePicker dtpDateInscription;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Label lblNom;
        private System.Windows.Forms.Label lblPrenom;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblNumeroEtudiant;
        private System.Windows.Forms.Label lblDateInscription;
        private System.Windows.Forms.Button btnEnregistrer;
        private System.Windows.Forms.Button btnAnnuler;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtId = new System.Windows.Forms.TextBox();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.txtPrenom = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtNumeroEtudiant = new System.Windows.Forms.TextBox();
            this.dtpDateInscription = new System.Windows.Forms.DateTimePicker();
            this.lblId = new System.Windows.Forms.Label();
            this.lblNom = new System.Windows.Forms.Label();
            this.lblPrenom = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblNumeroEtudiant = new System.Windows.Forms.Label();
            this.lblDateInscription = new System.Windows.Forms.Label();
            this.btnEnregistrer = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.SuspendLayout();


            this.txtId.Location = new System.Drawing.Point(139, 38);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(100, 20);
            this.txtId.TabIndex = 0;

            this.txtNom.Location = new System.Drawing.Point(139, 68);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(100, 20);
            this.txtNom.TabIndex = 1;

            this.txtPrenom.Location = new System.Drawing.Point(139, 98);
            this.txtPrenom.Name = "txtPrenom";
            this.txtPrenom.Size = new System.Drawing.Size(100, 20);
            this.txtPrenom.TabIndex = 2;

            this.txtEmail.Location = new System.Drawing.Point(139, 128);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(100, 20);
            this.txtEmail.TabIndex = 3;

            this.txtNumeroEtudiant.Location = new System.Drawing.Point(139, 158);
            this.txtNumeroEtudiant.Name = "txtNumeroEtudiant";
            this.txtNumeroEtudiant.Size = new System.Drawing.Size(100, 20);
            this.txtNumeroEtudiant.TabIndex = 4;

            this.dtpDateInscription.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateInscription.Location = new System.Drawing.Point(139, 188);
            this.dtpDateInscription.Name = "dtpDateInscription";
            this.dtpDateInscription.Size = new System.Drawing.Size(100, 20);
            this.dtpDateInscription.TabIndex = 5;

            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(22, 41);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(20, 13);
            this.lblId.TabIndex = 6;
            this.lblId.Text = "ID";

            this.lblNom.AutoSize = true;
            this.lblNom.Location = new System.Drawing.Point(22, 71);
            this.lblNom.Name = "lblNom";
            this.lblNom.Size = new System.Drawing.Size(29, 13);
            this.lblNom.TabIndex = 7;
            this.lblNom.Text = "Nom";

            this.lblPrenom.AutoSize = true;
            this.lblPrenom.Location = new System.Drawing.Point(22, 101);
            this.lblPrenom.Name = "lblPrenom";
            this.lblPrenom.Size = new System.Drawing.Size(41, 13);
            this.lblPrenom.TabIndex = 8;
            this.lblPrenom.Text = "Prénom";

            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(22, 131);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(32, 13);
            this.lblEmail.TabIndex = 9;
            this.lblEmail.Text = "Email";

            this.lblNumeroEtudiant.AutoSize = true;
            this.lblNumeroEtudiant.Location = new System.Drawing.Point(22, 161);
            this.lblNumeroEtudiant.Name = "lblNumeroEtudiant";
            this.lblNumeroEtudiant.Size = new System.Drawing.Size(82, 13);
            this.lblNumeroEtudiant.TabIndex = 10;
            this.lblNumeroEtudiant.Text = "Numéro d'étudiant";

            this.lblDateInscription.AutoSize = true;
            this.lblDateInscription.Location = new System.Drawing.Point(22, 191);
            this.lblDateInscription.Name = "lblDateInscription";
            this.lblDateInscription.Size = new System.Drawing.Size(91, 13);
            this.lblDateInscription.TabIndex = 11;
            this.lblDateInscription.Text = "Date d'inscription";

            this.btnEnregistrer.Location = new System.Drawing.Point(139, 218);
            this.btnEnregistrer.Name = "btnEnregistrer";
            this.btnEnregistrer.Size = new System.Drawing.Size(75, 23);
            this.btnEnregistrer.TabIndex = 12;
            this.btnEnregistrer.Text = "Enregistrer";
            this.btnEnregistrer.UseVisualStyleBackColor = true;
            this.btnEnregistrer.Click += new System.EventHandler(this.btnEnregistrer_Click);

            this.btnAnnuler.Location = new System.Drawing.Point(220, 218);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(75, 23);
            this.btnAnnuler.TabIndex = 13;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);

            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnEnregistrer);
            this.Controls.Add(this.lblDateInscription);
            this.Controls.Add(this.lblNumeroEtudiant);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblPrenom);
            this.Controls.Add(this.lblNom);
            this.Controls.Add(this.lblId);
            this.Controls.Add(this.dtpDateInscription);
            this.Controls.Add(this.txtNumeroEtudiant);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtPrenom);
            this.Controls.Add(this.txtNom);
            this.Controls.Add(this.txtId);
            this.Name = "Etudiant1";
            this.Text = "Etudiant1";
            this.Load += new System.EventHandler(this.Etudiant1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}