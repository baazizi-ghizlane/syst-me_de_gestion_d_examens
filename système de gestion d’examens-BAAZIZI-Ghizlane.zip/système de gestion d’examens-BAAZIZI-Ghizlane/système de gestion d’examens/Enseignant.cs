﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace système_de_gestion_d_examens
{
    internal class Enseignant
    {
        int id;
        string nom;
        string Prenom;
        string Email;
        string Specialite;

        public int Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Prenom1 { get => Prenom; set => Prenom = value; }
        public string Email1 { get => Email; set => Email = value; }
        public string Specialite1 { get => Specialite; set => Specialite = value; }
    }
}
