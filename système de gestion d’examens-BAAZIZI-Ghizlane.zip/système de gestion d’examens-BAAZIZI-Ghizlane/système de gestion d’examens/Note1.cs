﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using système_de_gestion_d_examens;

namespace système_de_gestion_d_examen
{
    public partial class Note1 : Form
    {
        public Note1()
        {
            InitializeComponent();
        }

        private void Note1_Load(object sender, EventArgs e)
        {

        }

        private void btnEnregistrer_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(txtId.Text);
                int etudiantId = int.Parse(txtEtudiantId.Text);
                int examenId = int.Parse(txtExamenId.Text);
                float valeur = float.Parse(txtValeur.Text);
                Note1 noteForm = new Note1();
                noteForm.ShowDialog();

                Note note = new Note { Id = id, EtudiantId = etudiantId, ExamenId = examenId, Valeur = valeur, Commentaire = txtCommentaire.Text };
                NoteDao noteDao = new NoteDao();
                NoteDao.Save(note);

                MessageBox.Show("Note enregistrée avec succès!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'enregistrement de la note: " + ex.Message);
            }
        }

        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
           
            label1.AutoSize = true;
            label1.Location = new Point(106, 35);
            label1.Name = "label1";
            label1.Size = new Size(30, 25);
            label1.TabIndex = 0;
            label1.Text = "ID";
            
            label2.AutoSize = true;
            label2.Location = new Point(97, 87);
            label2.Name = "label2";
            label2.Size = new Size(93, 25);
            label2.TabIndex = 1;
            label2.Text = "EtudiantId";
           
            label3.AutoSize = true;
            label3.Location = new Point(97, 130);
            label3.Name = "label3";
            label3.Size = new Size(89, 25);
            label3.TabIndex = 2;
            label3.Text = "ExamenId";
           
            label4.AutoSize = true;
            label4.Location = new Point(97, 171);
            label4.Name = "label4";
            label4.Size = new Size(60, 25);
            label4.TabIndex = 3;
            label4.Text = "Valeur";
            
            label5.AutoSize = true;
            label5.Location = new Point(97, 208);
            label5.Name = "label5";
            label5.Size = new Size(119, 25);
            label5.TabIndex = 4;
            label5.Text = "Commentaire";
            
            textBox1.Location = new Point(227, 81);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(150, 31);
            textBox1.TabIndex = 5;
           
            textBox2.Location = new Point(227, 124);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(150, 31);
            textBox2.TabIndex = 6;
            
            textBox3.Location = new Point(227, 165);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(150, 31);
            textBox3.TabIndex = 7;
           
            textBox4.Location = new Point(227, 208);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(150, 31);
            textBox4.TabIndex = 8;
           
            textBox5.Location = new Point(227, 32);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(150, 31);
            textBox5.TabIndex = 9;
           
            button1.Location = new Point(53, 262);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 10;
            button1.Text = "Enregistere";
            button1.UseVisualStyleBackColor = true;
            
            button2.Location = new Point(366, 262);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 11;
            button2.Text = "Annuler";
            button2.UseVisualStyleBackColor = true;
            
 
            ClientSize = new Size(909, 375);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Note1";
            Load += Note1_Load_1;
            ResumeLayout(false);
            PerformLayout();
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Note1_Load_1(object sender, EventArgs e)
        {

        }

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private Button button1;
        private Button button2;
    }
}