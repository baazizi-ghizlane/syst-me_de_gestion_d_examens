﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace système_de_gestion_d_examens
{
    internal class Administrateur
    {
        int id;
        string nom;
        string Prenom;
        string Email;
        string Role;


        public int Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Prenom1 { get => Prenom; set => Prenom = value; }
        public string Email1 { get => Email; set => Email = value; }
        public string Role1 { get => Role; set => Role = value; }
    }
}
