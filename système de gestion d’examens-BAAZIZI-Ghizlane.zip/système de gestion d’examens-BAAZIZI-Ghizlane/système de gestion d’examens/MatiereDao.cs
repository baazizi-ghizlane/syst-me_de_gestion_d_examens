﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace système_de_gestion_d_examens
{
    internal class MatiereDao
    {
        private List<Matiere> matieres = new List<Matiere>();

        public void Ajouter(Matiere m) => matieres.Add(m);
        public List<Matiere> Lister() => matieres;
        public Matiere RechercherParId(int id) => matieres.FirstOrDefault(m => m.Id == id);
        public void Supprimer(int id) => matieres.RemoveAll(m => m.Id == id);
    }
}
