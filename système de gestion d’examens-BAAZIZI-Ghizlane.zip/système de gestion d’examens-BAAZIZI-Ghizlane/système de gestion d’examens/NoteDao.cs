﻿using System;
using System.Collections.Generic;
using System.IO;

namespace système_de_gestion_d_examens
{
    internal class NoteDao
    {
        private static readonly string filePath = "C:\\Users\\Lenovo\\OneDrive - ISGA\\&isi cours\\S2\\c#\\système_de_gestion_d_examens\\Data\\notes.csv";

        public static List<Note> GetAll()
        {
            var notes = new List<Note>();
            if (!File.Exists(filePath)) return notes;

            foreach (var line in File.ReadAllLines(filePath))
            {
                var parts = line.Split(',');
                if (parts.Length >= 5)
                {
                    notes.Add(new Note
                    {
                        Id1 = int.Parse(parts[0]),
                        EtudiantId1 = int.Parse(parts[1]),
                        ExamenId1 = int.Parse(parts[2]),
                        Valeur1 = float.Parse(parts[3]),
                        Commentaire1 = parts[4]
                    });
                }
            }
            return notes;
        }

        public static void Save(Note n)
        {
            using (StreamWriter sw = File.AppendText(filePath))
            {
                sw.WriteLine($"{n.Id1},{n.EtudiantId1},{n.ExamenId1},{n.Valeur1},{n.Commentaire1}");
            }
        }
    }
}