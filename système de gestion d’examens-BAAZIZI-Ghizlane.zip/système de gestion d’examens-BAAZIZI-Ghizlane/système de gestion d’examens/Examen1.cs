
using System;
using System.Windows.Forms;
using syst�me_de_gestion_d_examens;

namespace syst�me_de_gestion_d_examen
{
    public partial class Examen1 : Form
    {
        private ExamenDao examenDao = new ExamenDao();

        public Examen1()
        {
            InitializeComponent();
        }

        private void Examen1_Load(object sender, EventArgs e)
        {

        }

        private void btnEnregistrer_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(txtId.Text);
                string nom = txtNom.Text;
                DateTime dateHeure = dtpDateHeure.Value;
                int duree = int.Parse(txtDuree.Text);
                int matiereId = int.Parse(txtMatiereId.Text);
                int enseignantId = int.Parse(txtEnseignantId.Text);
                string salle = txtSalle.Text;
                bool estTermine = cbEstTermine.Checked;

                Examen examen = new Examen
                {
                    Id = id,
                    Nom = nom,
                    DateHeure = dateHeure,
                    Duree = duree,
                    MatiereId = matiereId,
                    EnseignantId = enseignantId,
                    Salle = salle,
                    EstTermine = estTermine
                };

                ExamenDao.Save(examen);

                MessageBox.Show("Examen enregistr� avec succ�s!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'enregistrement de l'examen: " + ex.Message);
            }
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
