﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace système_de_gestion_d_examens
{
    internal class Session
    {
        int Id;
        string Nom;
        DateTime DateDebut;
        DateTime DateFin;
        bool EstActive;

        public int Id1 { get => Id; set => Id = value; }
        public string Nom1 { get => Nom; set => Nom = value; }
        public DateTime DateDebut1 { get => DateDebut; set => DateDebut = value; }
        public DateTime DateFin1 { get => DateFin; set => DateFin = value; }
        public bool EstActive1 { get => EstActive; set => EstActive = value; }
    }
}
