
using System;

namespace système_de_gestion_d_examen
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Système de Gestion des Examens";
            Console.WriteLine("====================================");
            Console.WriteLine("     BIENVENUE DANS L'APPLICATION   ");
            Console.WriteLine("====================================");
            Console.WriteLine("Veuillez choisir votre rôle :");
            Console.WriteLine("1. Étudiant");
            Console.WriteLine("2. Enseignant");
            Console.WriteLine("3. Administrateur");
            Console.Write("Votre choix : ");

            string choix = Console.ReadLine();

            switch (choix)
            {
                case "1":
                    MenuEtudiant();
                    break;
                case "2":
                    MenuEnseignant();
                    break;
                case "3":
                    MenuAdministrateur();
                    break;
                default:
                    Console.WriteLine("Choix invalide !");
                    break;
            }

            Console.WriteLine("\nAppuyez sur une touche pour quitter...");
            Console.ReadKey();
        }

        static void MenuEtudiant()
        {
            Console.Clear();
            Console.WriteLine("=== Menu Étudiant ===");
            Console.WriteLine("1. Consulter les examens à venir");
            Console.WriteLine("2. Voir mes notes");
            Console.WriteLine("3. Télécharger mon relevé de notes");
            Console.WriteLine("4. S'inscrire à un examen");
        }

        static void MenuEnseignant()
        {
            Console.Clear();
            Console.WriteLine("=== Menu Enseignant ===");
            Console.WriteLine("1. Créer un examen");
            Console.WriteLine("2. Saisir les notes");
            Console.WriteLine("3. Voir liste des étudiants");
            Console.WriteLine("4. Générer statistiques");
        }

        static void MenuAdministrateur()
        {
            Console.Clear();
            Console.WriteLine("=== Menu Administrateur ===");
            Console.WriteLine("1. Gérer utilisateurs");
            Console.WriteLine("2. Gérer matières");
            Console.WriteLine("3. Gérer sessions");
            Console.WriteLine("4. Publier résultats");
        }
    }
}
