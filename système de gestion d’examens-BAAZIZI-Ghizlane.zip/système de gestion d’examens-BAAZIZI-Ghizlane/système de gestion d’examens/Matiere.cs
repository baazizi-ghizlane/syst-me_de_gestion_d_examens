﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace système_de_gestion_d_examens
{
    internal class Matiere
    {
        int id;
        string nom;
        string Code;
        int Coefficient;

        public int Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Code1 { get => Code; set => Code = value; }
        public int Coefficient1 { get => Coefficient; set => Coefficient = value; }
    }
}
