﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using système_de_gestion_d_examen;

namespace système_de_gestion_d_examens
{

    internal class Note
    {
        int Id;
        int EtudiantId;
        int ExamenId;
        float Valeur;
        string Commentaire;

        public int Id1 { get => Id; set => Id = value; }
        public int EtudiantId1 { get => EtudiantId; set => EtudiantId = value; }
        public int ExamenId1 { get => ExamenId; set => ExamenId = value; }
        public float Valeur1 { get => Valeur; set => Valeur = value; }
        public string Commentaire1 { get => Commentaire; set => Commentaire = value; }
    }

}
