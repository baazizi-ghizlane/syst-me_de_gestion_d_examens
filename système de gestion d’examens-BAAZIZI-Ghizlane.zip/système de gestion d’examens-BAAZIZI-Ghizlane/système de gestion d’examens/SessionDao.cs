﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace système_de_gestion_d_examens
{
    internal class SessionDao
    {
        private List<Session> sessions = new List<Session>();

        public void Ajouter(Session s) => sessions.Add(s);
        public List<Session> Lister() => sessions;
        public Session RechercherParId(int id) => sessions.FirstOrDefault(s => s.Id1 == id);
        public List<Session> RechercherActives() => sessions.Where(s => s.EstActive1).ToList();
        public void Supprimer(int id) => sessions.RemoveAll(s => s.Id1 == id);
    }
}
