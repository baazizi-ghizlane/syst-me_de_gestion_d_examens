﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace système_de_gestion_d_examen
{
    public partial class Matiere1 : Form
    {
        public Matiere1()
        {
            InitializeComponent();
        }
    }
}
